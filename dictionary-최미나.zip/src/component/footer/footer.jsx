const Footer = ()=>{
    return(
        <footer>
            <ul>
                <li>제작 : 최미나</li>
                <li>email : eii1998@naver.com</li>
            </ul>
        </footer>
    )
}

export default Footer;